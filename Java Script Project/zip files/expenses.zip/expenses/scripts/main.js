import { onStart } from "./dom.js";

onStart();
